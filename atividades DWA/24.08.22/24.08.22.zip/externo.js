alert("foi")

const copinho = "Eu consegui fazer o TP"
document.writeln(copinho)
console.log(copinho)